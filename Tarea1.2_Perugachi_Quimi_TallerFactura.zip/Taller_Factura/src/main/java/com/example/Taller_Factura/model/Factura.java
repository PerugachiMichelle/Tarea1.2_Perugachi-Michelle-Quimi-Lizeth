package com.example.Taller_Factura.model;

import java.util.List;

public class Factura {
    private List<Producto> productos;
    private double subtotal;
    private double descuento;
    private double iva;
    private double impuestoEspecial;
    private double total;

    // Getters y Setters
    public List<Producto> getProductos() { return productos; }
    public void setProductos(List<Producto> productos) { this.productos = productos; }

    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }

    public double getDescuento() { return descuento; }
    public void setDescuento(double descuento) { this.descuento = descuento; }

    public double getIva() { return iva; }
    public void setIva(double iva) { this.iva = iva; }

    public double getImpuestoEspecial() { return impuestoEspecial; }
    public void setImpuestoEspecial(double impuestoEspecial) { this.impuestoEspecial = impuestoEspecial; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
}
