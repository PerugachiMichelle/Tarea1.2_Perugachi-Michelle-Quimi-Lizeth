package com.example.Taller_Factura.model;

public class Producto {
    private String nombre;
    private double precio;
    private int cantidad;
    private boolean consumoEspecial;

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public boolean isConsumoEspecial() { return consumoEspecial; }
    public void setConsumoEspecial(boolean consumoEspecial) { this.consumoEspecial = consumoEspecial; }

    public double getSubtotal() {
        return precio * cantidad;
    }
}
