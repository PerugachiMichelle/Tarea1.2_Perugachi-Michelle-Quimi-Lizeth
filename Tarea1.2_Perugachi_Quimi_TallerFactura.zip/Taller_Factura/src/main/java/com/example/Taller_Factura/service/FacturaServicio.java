package com.example.Taller_Factura.service;

import com.example.Taller_Factura.model.Factura;
import com.example.Taller_Factura.model.Producto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FacturaServicio {

    public Factura calcularFactura(List<Producto> productos, double ivaPorcentaje) {
        double subtotal = 0.0;
        double iva = 0.0;
        double impuestoEspecial = 0.0;
        double descuento = 0.0;

        // Recorrer productos
        for (Producto producto : productos) {
            double productoSubtotal = producto.getSubtotal();
            subtotal += productoSubtotal;

            if (producto.isConsumoEspecial()) {
                impuestoEspecial += productoSubtotal * 0.10;
            }
        }

        // Descuento según subtotal
        if (subtotal > 300) {
            descuento = subtotal * 0.07;
        } else if (subtotal > 200) {
            descuento = subtotal * 0.05;
        }

        // IVA se calcula sobre subtotal - descuento
        iva = (subtotal - descuento) * ivaPorcentaje;

        // Total factura
        double total = subtotal - descuento + iva + impuestoEspecial;

        // Preparar Factura
        Factura factura = new Factura();
        factura.setProductos(productos);
        factura.setSubtotal(subtotal);
        factura.setDescuento(descuento);
        factura.setIva(iva);
        factura.setImpuestoEspecial(impuestoEspecial);
        factura.setTotal(total);

        return factura;
    }
}
