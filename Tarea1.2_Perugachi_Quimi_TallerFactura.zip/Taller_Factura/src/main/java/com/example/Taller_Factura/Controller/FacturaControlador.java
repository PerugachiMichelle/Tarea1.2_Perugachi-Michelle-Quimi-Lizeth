package com.example.Taller_Factura.Controller;

import com.example.Taller_Factura.model.Factura;
import com.example.Taller_Factura.model.Producto;
import com.example.Taller_Factura.service.FacturaServicio;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Controller
public class FacturaControlador {

    private List<Producto> productos = new ArrayList<>();

    @Autowired
    private FacturaServicio facturaServicio;

    @GetMapping("/")
    public String mostrarFormulario(Model model) {
        model.addAttribute("producto", new Producto());
        model.addAttribute("productos", productos);
        return "formulario";
    }

    @PostMapping("/agregar")
    public String agregarProducto(@ModelAttribute Producto producto) {
        productos.add(producto);
        return "redirect:/";
    }

    @GetMapping("/calcular")
    public String calcularFactura(@RequestParam(defaultValue = "0.15") double iva, Model model) {
        Factura factura = facturaServicio.calcularFactura(productos, iva);
        model.addAttribute("factura", factura);
        return "resultado";
    }

    @GetMapping("/eliminar/{indice}")
    public String eliminarProducto(@PathVariable int indice) {
        if (indice >= 0 && indice < productos.size()) {
            productos.remove(indice);
        }
        return "redirect:/";
    }

    @GetMapping("/descargar-pdf")
    public void descargarPDF(HttpServletResponse response, @RequestParam(defaultValue = "0.15") double iva) throws IOException, DocumentException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=factura.pdf");

        Factura factura = facturaServicio.calcularFactura(productos, iva);

        Document document = new Document();
        PdfWriter.getInstance(document, response.getOutputStream());

        document.open();
        document.add(new Paragraph("FACTURA"));
        document.add(new Paragraph(" "));

        PdfPTable table = new PdfPTable(4);
        table.setWidthPercentage(100);
        table.setWidths(new int[]{3, 2, 2, 2});

        table.addCell("Producto");
        table.addCell("Precio");
        table.addCell("Cantidad");
        table.addCell("Subtotal");

        for (Producto producto : factura.getProductos()) {
            table.addCell(producto.getNombre());
            table.addCell(String.format("$%.2f", producto.getPrecio()));
            table.addCell(String.valueOf(producto.getCantidad()));
            table.addCell(String.format("$%.2f", producto.getSubtotal()));
        }

        document.add(table);
        document.add(new Paragraph(" "));

        document.add(new Paragraph(String.format("Subtotal: $%.2f", factura.getSubtotal())));
        document.add(new Paragraph(String.format("Descuento: $%.2f", factura.getDescuento())));
        document.add(new Paragraph(String.format("IVA (%.0f%%): $%.2f", iva * 100, factura.getIva())));
        document.add(new Paragraph(String.format("Impuesto Especial (10%%): $%.2f", factura.getImpuestoEspecial())));
        document.add(new Paragraph(String.format("TOTAL: $%.2f", factura.getTotal())));

        document.close();
    }
}
